package com.basicstrong.spring;

import com.basicstrong.annotation.ComponentScan;
import com.basicstrong.annotation.Configuration;

@Configuration
@ComponentScan("com.basicstrong.spring")
public class AppConfig {

}
