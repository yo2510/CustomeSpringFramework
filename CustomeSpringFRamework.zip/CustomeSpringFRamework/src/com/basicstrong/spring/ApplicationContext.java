package com.basicstrong.spring;

import java.io.File;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.util.HashMap;

import com.basicstrong.annotation.Autowired;
import com.basicstrong.annotation.Component;
import com.basicstrong.annotation.ComponentScan;
import com.basicstrong.annotation.Configuration;

public class ApplicationContext {
	private static HashMap<Class, Object> map = new HashMap<>();
	
	public ApplicationContext(Class<AppConfig> class1) {
		Spring.initializeSpringContext(class1);
	}

	
	private static class Spring {
		private static void initializeSpringContext(Class<?> class1 ) {
			if(!class1.isAnnotationPresent(Configuration.class)) {
				throw new RuntimeException("The file is not a Configuration file.");
			}
			else {
				ComponentScan annotion = class1.getAnnotation(ComponentScan.class);
				String value = annotion.value();
				
				String packageStructure = "bin/"+value.replace(".", "/") ;
				File[] files = findClasses(new File(packageStructure));
				for (File file : files) {
					String name = value+"."+file.getName().replace(".class", "");
					try {
						Class<?> loadingClass = Class.forName(name);
						if(loadingClass.isAnnotationPresent(Component.class)) {
							Constructor<?> constructor = loadingClass.getConstructor();
							Object newInstance = constructor.newInstance();
							map.put(loadingClass, newInstance);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
		}

		private static File[] findClasses(File file) {
			if(!file.exists()) {
				throw new RuntimeException("Package "+file+" does not exist");
			} else {
				File[] listFiles = file.listFiles(e-> e.getName().endsWith(".class"));
				return listFiles;
			}
		}
	}


	public <T> T getBean(Class<T> class1) {
		T object = (T) map.get(class1);
		Field[] declaredFields = class1.getDeclaredFields();
		injectBean(object, declaredFields);
		return object;
	}


	private <T> void injectBean(T object, Field[] declaredFields) {
		for(Field field : declaredFields) {
			if(field.isAnnotationPresent(Autowired.class)) {
				field.setAccessible(true);
				Class<?> type = field.getType();
				Object innerObject = map.get(type);
				try {
					field.set(object, innerObject);
					Field[] declaredFields2 = type.getDeclaredFields();
					injectBean(innerObject, declaredFields2);
				} catch (IllegalArgumentException | IllegalAccessException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
}
